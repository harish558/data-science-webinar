print("Hello World")
print("New World")