print("Hello World")
print("New World", c)