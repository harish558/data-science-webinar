#include<stdio.h>

int main() {
    int a, b;
    a =10;
    b=20;
    printf("%d\n", a+b);
}