#include<stdio.h>

int main() {
    printf("Hello World\n");
    printf("New World \n")
    return 0;
}